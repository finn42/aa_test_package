# Example Activity Analysis file

This is a first take at making a python library. Module of activty analysis, statistic tools for assessing concurrent activity in collections of time series. 

You can use [Github-flavored Markdown](https://guides.github.com/features/mastering-markdown/) to write your content.